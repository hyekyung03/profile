document.addEventListener("DOMContentLoaded",()=>{

    const header = document.querySelector("#header")
    const btnMenu = document.querySelector(".btn-menu")

     // 마우스 휠을 올리거나 내릴 때 사용하는 소스코드
    let lastScrollTop = 0
    window.addEventListener("scroll",()=>{
        let scrollTop = window.pageYOffset || document.documentElement.scrollTop // 브라우저의 호환성을 생각하여 스크롤바가 내려온 길이를 계산

        if(scrollTop < lastScrollTop){
            // 마우스 휠을 위로 굴렸을 때
            header.classList.remove("fadein")
            // btnMenu.classList.remove("fadeout")
            // mobileHeader.classList.add("fadeout")
            mobileState = false
            btnMenuImg.innerHTML = "menu"
            // btnMenuImg.setAttribute("src","./img/menu.svg")
            btnMenu.classList.remove("fixed")
        }else{
            // 마우스 휠을 아래로 굴렸을 때
            header.classList.remove("fadein")
            // btnMenu.classList.add("fadeout")
            // mobileHeader.classList.add("fadeout")
            mobileState = false
            btnMenuImg.innerHTML = "menu"
            // btnMenuImg.setAttribute("src","./img/menu.svg")
            btnMenu.classList.remove("fixed")
        }
        lastScrollTop = scrollTop
    })

    // const mobileHeader = document.querySelector(".header-smart")
    let mobileState = false // 메뉴가 현재 닫혀있는 상태
    const btnMenuImg = document.querySelector(".btn-menu-span")

    btnMenu.addEventListener("click",()=>{
        if(mobileState == false){
            // 메뉴를 여는 경우
            header.classList.add("fadein")    
            mobileState = true
            btnMenuImg.innerHTML = "close"
            btnMenu.classList.add("fixed")
        }else{
            // 메뉴를 닫는 경우
            header.classList.remove("fadein")    
            mobileState = false
            btnMenuImg.innerHTML = "menu"
            btnMenu.classList.remove("fixed")
        }
        
    })






})